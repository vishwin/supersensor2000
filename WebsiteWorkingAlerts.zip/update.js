//insert code here to get data from middleware (from arduino)


//humidity variables
var hum = 60;

/*var hum = io();
hum.on('data', function(data) {
  console.log(data);
  document.getElementById('')
}); */
const humhigh = 65;
const humlow = 55 ;

//airtemp variables
var airtemp = 80;

/*var airtemp = io();
airtemp.on('data', function(data) {
  console.log(data);
  document.getElementById('')
});*/
const airlow = 77;
const airhigh = 91;

//soiltemp variables
var soiltemp = 90;
/*var soiltemp = io();
soiltemp.on('data', function(data) {
  console.log(data);
  document.getElementById('')
});*/
const soillow = 65;
const soilhigh = 95;

//airpressure variables (in pascals)
var airpr = 9000;
/*var airpr = io();
airpr.on('data', function(data) {
  console.log(data);
  document.getElementById('')
});*/
const prhigh = 108380 ;
const prlow = 8700;

var light = "True";
/*var light = io();
light.on('data', function(data) {
  console.log(data);
  document.getElementById('')
});*/

  document.getElementById("humidity").innerHTML = hum;
  document.getElementById("airtemp").innerHTML = airtemp;
  document.getElementById("light").innerHTML = light;
  document.getElementById("soiltemp").innerHTML = soiltemp;
  document.getElementById("airpres").innerHTML = airpr;
  
  
  document.getElementById("")

if ((humlow<hum && hum<humhigh) && (airlow<airtemp && airtemp<airhigh) && (soillow<soiltemp && soiltemp<soilhigh) && (prlow<airpr && airpr<prhigh))
  {
    document.write("<h4>There are no current issues! 😀</h4>");
  }
else
{
  if(humlow > hum){
  document.write("<h3> ❗  Humidity is too low</h3>");
  }
  else if(hum > humhigh){
    document.write("<h3> ❗ Humidity is too high</h3>");
  }

  if(airlow > airtemp){
  document.write("<h3> ❗ Air temperature is too low</h3>");
  }
  else if(airtemp > airhigh){
    document.write("<h3> ❗ Air temperature is too high</h3>");
  }
  
  if(soillow > soiltemp){
  document.write("<h3> ❗ Soil temperature is too low</h3>");
  }
  else if(soiltemp > soilhigh){
    document.write("<h3> ❗ Soil temperature is too high</h3>");
  }

  if(prlow > airpr){
  document.write("<h3> ❗ Air pressure is too low</h3>");
  }
  else if(airpr > prhigh){
    document.write("<h3> ❗ Air pressure is too high</h3>");
  }


  //document.getElementById("humDC").data-color = hum;

}





